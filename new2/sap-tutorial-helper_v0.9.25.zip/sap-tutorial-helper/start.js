'use babel';

import src from './dist/main.js';

export default src.default;
