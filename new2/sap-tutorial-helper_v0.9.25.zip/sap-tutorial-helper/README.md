# sap-tutorial-helper

Preview, create and validate your SAP tutorials in Atom editor.

Main features:
- preview
- validation
- new tutorial creation using template
- auto update / check for updates
- push to QA repository
- push to production repository
- insert template

Supported shortcuts:
- Alt+Shift+V - runs validation
- Alt+Shift+Q - opens preview
- Alt+Shift+T - creates new tutorial inside tutorials folder

## For developers:
Run `npm run lint` to perform eslint analysis
You can use scripts/build to create new build, delete old and commit these actions.
How to pass the task to the QA?
Update the version, create new build and publish it in `master/utilities`, move the task in Jira to Resolved and assign to QA engineer, their plugin should detect new version from dev repo automatically

## Auto Update
Plugin checks for updates each time user loads Atom or on the user request.
By default plugin will look for new version in QA repository, if user checks _Use Development Version_ in the plugin settings,
plugin will look for new version in the [development repository](https://github.wdf.sap.corp/DigitalPlatforms/com.sap.developers.markdown.validator)

### How to upload new version to Tutorials-Contribution

- call`npm version <command>` (lint check will be done before creating a new version, `npm run build` will be executed after a new version created)
- create PR to master branch
