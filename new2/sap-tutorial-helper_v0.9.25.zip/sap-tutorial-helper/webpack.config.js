const path = require('path');
const glob = require('glob');
const webpack = require('webpack');

const { name: PLUGIN_NAME } = require('./package');

const specs = [...glob.sync('./tests/*?/*.js'), ...glob.sync('./tests/*.js')];

const entry = {
  'dist/main.js': './lib',
};

specs.reduce((result, filePath) => {
  entry[`spec/${path.basename(filePath)}`] = filePath;

  return entry;
}, entry);

const { INIT_CWD } = process.env;

module.exports = {
  mode: process.env.NODE_ENV || 'development',
  entry,
  output: {
    path: INIT_CWD,
    filename: './[name]',
    library: '',
    libraryTarget: 'commonjs',
  },
  resolve: {
    alias: {
      static: path.resolve(INIT_CWD, 'static/'),
      'static-fallback': path.resolve(INIT_CWD, 'static-fallback/'),
    },
  },
  module: {
    rules: [
      {
        test: /\.m?js$/,
        exclude: /(node_modules)/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              ['@babel/preset-env', {
                targets: {
                  chrome: 69,
                },
                useBuiltIns: 'usage',
                corejs: 3,
              }],
              '@babel/preset-react',
              'minify',
            ],
            plugins: [
              '@babel/plugin-proposal-export-default-from',
              'transform-function-bind',
            ],
          },
        },
      },
    ],
  },
  plugins: [
    new webpack.DefinePlugin({
      PLUGIN_NAME: JSON.stringify(PLUGIN_NAME),
      PLUGIN_HOME: JSON.stringify(INIT_CWD),
    }),
  ],
  target: 'electron-renderer',
  externals: {
    atom: 'commonjs atom',
    fuzzaldrin: 'fuzzaldrin',
    classnames: 'classnames',
    marked: 'marked',
    mkdirp: 'mkdirp',
    react: 'react',
    got: 'got',
    'node-fetch': 'node-fetch',
    'adm-zip': 'adm-zip',
    'compare-versions': 'compare-versions',
    'fs-extra': 'fs-extra',
    'fs-plus': 'fs-plus',
    'react-dom': 'react-dom',
    'recursive-copy': 'recursive-copy',
    'http-status-codes': 'http-status-codes',
  },
};
